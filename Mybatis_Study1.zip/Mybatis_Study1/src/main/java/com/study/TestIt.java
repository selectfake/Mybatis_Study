package com.study;


import com.study.dao.DianYingDao;
import com.study.dao.LeiXingDao;
import com.study.entity.DianYingXinXi;
import com.study.entity.LeiXing;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.Reader;
import java.util.List;

/**
 * @author zr_kcool
 * @date 2022/2/21
 * @TIME 16:54
 */
public class TestIt {
  public static void main(String[] args) throws Exception {
    //   用工具类封装前三步重用功能
    SqlSessionFactory sf = MyBatisUtil.getSqlSessionFactory();
    //4.打开 sql session
    SqlSession se = sf.openSession();
//    获得电影dao代理
    DianYingDao dao =se.getMapper(DianYingDao.class);
    DianYingXinXi dy = new DianYingXinXi();
    dy.setDaoYan("张艺谋");
    dy.setId(8);
    dy.setLeixingId(1);
    dy.setMing("红高粱666");
    dy.setPiaoJia(10f);
    dy.setYanYuan("灰太狼");
    dao.deleteDianYingById(dy);
//    dao.updateDianYing(dy);
//    dao.insertDianYing(dy);
    se.commit();//提交事物
    se.close();
  }

  private static void hehe() {
    //   用工具类封装前三步重用功能
    SqlSessionFactory sf = MyBatisUtil.getSqlSessionFactory();

//4.打开 sql session
    SqlSession se = sf.openSession();
    //创建一个类型对象
    LeiXing lx = new LeiXing();
    lx.setId(1);
    lx.setLeiXing("hehe");
//    用sqlsession的GetMapper方法获得接口对应的代理对象
    LeiXingDao dao = se.getMapper(LeiXingDao.class);
    LeiXing lxs = dao.chaLeiXingByLeiXing(lx);
    if (lxs != null) {
      System.out.println(lxs.getLeiXing());
    }
    se.close();
  }

  private static void parameterLeiXing() {
    //   用工具类封装前三步重用功能
    SqlSessionFactory sf = MyBatisUtil.getSqlSessionFactory();

//4.打开 sql session
    SqlSession se = sf.openSession();
    //创建一个类型对象
    LeiXing lx = new LeiXing();
    lx.setId(1);
    lx.setLeiXing("hehe");

//5.执行 sql
    LeiXing lxs = se.selectOne("com.study.dao.LeiXingDao.chaLeiXingByLeiXing", lx);
  }

  private static void chaById() {
    //   用工具类封装前三步重用功能
    SqlSessionFactory sf = MyBatisUtil.getSqlSessionFactory();
//4.打开 sql session
    SqlSession se = sf.openSession();
//5.执行 sql
    List<LeiXing> lxs = se.selectList("com.study.dao.LeiXingDao.chaLeiXingById", 1);
    //6.输出
    for (LeiXing lx : lxs)
      System.out.println(lx.getLeiXing());
    se.close();
  }

  private static void testFirst() {
    //   用工具类封装前三步重用功能
    SqlSessionFactory sf = MyBatisUtil.getSqlSessionFactory();
//4.打开 sql session
    SqlSession se = sf.openSession();
//5.执行 sql
    List<LeiXing> lxs =
            se.selectList("com.study.dao.LeiXingDao.chaLeiXing");
//6.输出
    for (LeiXing lx : lxs)
      System.out.println(lx.getLeiXing());
    se.close();
  }
}