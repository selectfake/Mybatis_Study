package com.study.entity;

/**
 * @author zr_kcool
 * @date 2022/2/21
 * @TIME 16:49
 */
public class LeiXing {
  private Integer id;
  private String LeiXing;


  public String getLeiXing() {
    return LeiXing;
  }

  public void setLeiXing(String leiXing) {
    LeiXing = leiXing;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }
}

